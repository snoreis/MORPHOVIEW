function [A_Density,logA_Density] = CellDensityCalculation(FileName, A, B, WriteTiff)
%% Determine cell density

B_Centroid_array = B.Centroid;
B_Volume_array = B.Volume;

CountDistance = 50;
NumOfCells = max(max(max(A)))
CellConcentration = zeros(1,NumOfCells);

tic
f = waitbar(0,'1','Name','Please Wait...',...
    'CreateCancelBtn','setappdata(gcbf,''canceling'',1)');

setappdata(f,'canceling',0);

for i = 1:NumOfCells
    if getappdata(f,'canceling')
        break
    end

    % Update waitbar and message
    waitbar(double(i)/double(NumOfCells))

    ObjDistance = zeros(1,NumOfCells);
    for j = 1:NumOfCells
        ObjDistance(j) = norm(B_Centroid_array(i,:)-B_Centroid_array(j,:));
    end
    %[sortedObjDistance,indexes] = sort(ObjDistance);
    DistanceBool = ObjDistance<CountDistance;
    CellCount = sum(DistanceBool);
    TotalVolume = sum(B_Volume_array'.*DistanceBool);
    CellConcentration(1,i) = CellCount./TotalVolume;
end
toc
delete(f)

tic
A_Density = zeros(size(A));
for i = 1:size(A,1)
    i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_Density(i,j,k) = CellConcentration(1,index);
            end
        end
    end
end
toc

logA_Density = log10(A_Density+1e-07);

P_logA_Density = prctile(log10(CellConcentration+1e-07),[1 5 95 99 99.9],"all")
figure, orthosliceViewer((logA_Density),"Colormap",gray, "DisplayRange",[-4.6 -3.5])
title('Cell Concentration (log_10)')


% Output as Tiff
if WriteTiff == 1
    logA_Density_Scale = logA_Density-(P_logA_Density(1));
    logA_Density_Scale = logA_Density_Scale/((P_logA_Density(5))-(P_logA_Density(1)));

    filenametiff = FileName + "_Density.tiff"
    im1 = logA_Density_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(logA_Density_Scale,3)
        im2 = logA_Density_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end

end