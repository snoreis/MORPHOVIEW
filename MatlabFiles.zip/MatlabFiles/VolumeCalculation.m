%% Volume Calculation
function [A_vol] = VolumeCalculation(FileName, A, B, WriteTiff)

B_Volume_array = B.Volume;

A_vol = zeros(size(A));
for i = 1:size(A,1)
    PercentFinished = i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_vol(i,j,k) = B_Volume_array(index,1);
            end
        end
    end
end

figure, sliceViewer((A_vol),"Colormap",parula, "DisplayRange",[0 62698])
title('Convex Cell Volume')


% Output as Tiff
if WriteTiff == 1
    A_vol_Scale = A_vol-0;
    A_vol_Scale = A_vol_Scale/(62698-0);

    filenametiff = FileName + "_Volume.tiff"
    im1 = A_vol_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_vol_Scale,3)
        im2 = A_vol_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end

end