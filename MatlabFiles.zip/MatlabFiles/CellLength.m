%% Cell Length
function [B_Axis_array_Long] = CellLength(FileName, A, B, WriteTiff)

B_Axis_array = B.PrincipalAxisLength;
B_Axis_array_Long = B_Axis_array(:,1);

A_PAL1 = zeros(size(A));

tic
for i = 1:size(A,1)
    i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_PAL1(i,j,k) = B_Axis_array_Long(index,1);

            end
        end
    end
end
toc

%figure, histogram(A_PAL1)
%median(median(median(A_PAL1)))
%max(max(max(A_PAL1)))
P_A_PAL1 = prctile(B_Axis_array_Long,[1 5 10 20 95 99 99.9],"all")
figure, sliceViewer((A_PAL1),"Colormap",parula, "DisplayRange",[0 95])
title('Cell Length')


% Output as Tiff
if WriteTiff == 1
    A_PAL1_Scale = A_PAL1-0;
    A_PAL1_Scale = A_PAL1_Scale/(95-0);

    filenametiff = FileName + "_MajorAxis.tiff"
    im1 = A_PAL1_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_PAL1_Scale,3)
        im2 = A_PAL1_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end
end