%%
clear all
close all
clc

 %% 
 BaseFileName = "n42/convextest/Experiment1_PostProK_n42Shark_01_Section1_Stitched";
 
 %Raw Image
 RawImage = tiffreadVolume(BaseFileName + "_C2.tif");
 
 %Corresponding segmented cells
 A = tiffreadVolume(BaseFileName + '_Gamma_cp_masks_04.tif');

%% Calculate region properties

B = regionprops3(A,RawImage,"ConvexHull", "Centroid", "Volume", "MeanIntensity", "PrincipalAxisLength", "ConvexVolume", "Solidity", "BoundingBox", "ConvexImage", "SurfaceArea");

% Calculate Convex region properties
[A_Convex] = CreateConvexHullImage(BaseFileName, A, B, 1);
B_Convex = regionprops3(A_Convex,RawImage, "Centroid", "Volume", "MeanIntensity", "PrincipalAxisLength", "ConvexHull", "SurfaceArea");


%% Create individual property heat maps
[A_Orientation_Convex] = OrientationCalculation(FileName, A_Convex, B_Convex, RawImage, 1);
[A_vol_Convex] = VolumeCalculation(FileName, A_Convex, B_Convex, 1);
[A_Actin_Convex] = ActinConcentration(FileName, A_Convex, B_Convex,RawImage, 1);
[A_PAL_R_Convex] = MajorMinorRatio(FileName, A_Convex, B_Convex, 1);
[B_Axis_array_Long_Convex] = CellLength(FileName, A_Convex, B_Convex, 1);
[A_Sphericity_Convex,...
    A_Sphericity_Ellipsoid_Convex,...
    B_Sphericity_array,...
    B_Sphericity_array_Ellipsoid] = SphericityCalculation(BaseFileName, A_Convex, B_Convex, 0);
[A_Density_Convex,logA_Density_Convex] = CellDensityCalculation(FileName, A_Convex, B_Convex, 1);

%% Output as Gif
% s = sliceViewer(A_vol,"Parent",figure,"Colormap",parula, "DisplayRange",[P_vol(1) P_vol(5)])
% colorbar
% 
% hAx = getAxesHandle(s);
% filenamegif = FileName + "_Volume.gif"
% sliceNums = 1:size(A,3);
% for idx = sliceNums
%     % Update slice number
%     s.SliceNumber = idx;
%     % Use getframe to capture image
%     I = getframe(hAx);
%     [indI,cm] = rgb2ind(I.cdata,256);
%     % Write frame to the GIF file
%     if idx == 1
%         imwrite(indI,cm,filenamegif,"gif","Loopcount",inf,"DelayTime", 0.01);
%     else
%         imwrite(indI,cm,filenamegif,"gif","WriteMode","append","DelayTime", 0.01);
%     end
% end




