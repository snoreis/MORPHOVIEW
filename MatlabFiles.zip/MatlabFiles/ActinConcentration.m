%% Actin concentration
function [A_Actin] = ActinConcentration(FileName, A, B,RawImage, WriteTiff)

B_ActinConc_array = B.MeanIntensity;
A_Actin = zeros(size(A));

tic
for i = 1:size(A,1)
    PercentFinished = i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_Actin(i,j,k) = B_ActinConc_array(index,1);
            end
        end
    end
end
toc

%figure, histogram(A_Actin)
%median(median(median(A_Actin)))
%max(max(max(A_Actin)))
P_Actin = prctile(B_ActinConc_array,[1 5 97 99.5 99.9],"all")
figure, sliceViewer((A_Actin),"Colormap",parula, "DisplayRange",[P_Actin(1) P_Actin(4)])
title('Actin Concentration per cell')

%max(max(max(A_Actin)))
RawImage_Scale = double(RawImage);
P_ActinRaw = prctile(RawImage_Scale,[1 5 95 99 99.9],"all")
figure, sliceViewer(RawImage_Scale,"Colormap",parula, "DisplayRange",[P_ActinRaw(1) P_ActinRaw(5)])
title('Actin Concentration')





% Output as Tiff
if WriteTiff == 1
    A_Actin_Scale = A_Actin-P_Actin(1);
    A_Actin_Scale = A_Actin_Scale/(P_Actin(4)-P_Actin(1));

    filenametiff = FileName + "_Actin.tiff"
    im1 = A_Actin_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_Actin_Scale,3)
        im2 = A_Actin_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end

end
end