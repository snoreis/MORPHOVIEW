function [A_Sphericity, A_Sphericity_Ellipsoid, B_Sphericity_array, B_Sphericity_array_Ellipsoid] = SphericityCalculation(FileName, A, B, WriteTiff)

B_SA_array = B.SurfaceArea;
B_Volume_array = B.Volume;
B_Sphericity_array = (pi^(1/3)*(6*B_Volume_array).^(2/3))./B_SA_array;


% Analytical Ellipsoid approximation
B_Axis_array = B.PrincipalAxisLength;

a = B_Axis_array(:,1);
b = B_Axis_array(:,2);
c = B_Axis_array(:,3);

B_SA_array_Ellipsoid = 4*pi*(((a.*b).^1.6+(b.*c).^1.6+(a.*c).^1.6)/3).^(1/1.6);
B_Volume_array_Ellipsoid = 4/3.*pi.*a.*b.*c;
B_Sphericity_array_Ellipsoid = (pi^(1/3)*(6*B_Volume_array_Ellipsoid).^(2/3))./B_SA_array_Ellipsoid;
clear a b c

% Surface area numerical approximation
% B_SA_array_Num = zeros(length(B_Axis_array),1);
% B_Sphericity_array_Num = zeros(length(B_Axis_array),1);
%
% for i = 1:length(B_Axis_array)
%     i/length(B_Axis_array)*100
%     [X,Y,Z] = ellipsoid(0,0,0,B_Axis_array(i,1),B_Axis_array(i,2),B_Axis_array(i,3));
%     X = X(:);
%     Y = Y(:);
%     Z = Z(:);
%     P = unique([X Y Z],'rows');
%     shp = alphaShape(P,1.5);
%     a = criticalAlpha(shp,'one-region');
%     shp = alphaShape(P,a);
%     B_SA_array_Num(i) = surfaceArea(shp);
%     VolumeTemp = 4/3*pi*B_Axis_array(i,1)*B_Axis_array(i,2)*B_Axis_array(i,3);
%     B_Sphericity_array_Num(i) = (pi^(1/3)*(6*VolumeTemp)^(2/3))/B_SA_array_Num(i);
%     clear X Y Z P shp
% end

% Make volume
A_Sphericity_Ellipsoid = zeros(size(A));
A_Sphericity = zeros(size(A));
tic
for i = 1:size(A,1)
    i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_Sphericity_Ellipsoid(i,j,k) = B_Sphericity_array_Ellipsoid(index,1);
                A_Sphericity(i,j,k) = B_Sphericity_array(index,1);
            end
        end
    end
end
toc

P_A_Sphericity = prctile(B_Sphericity_array_Ellipsoid,[1 5 20 95 99 99.9 100],"all")

figure, sliceViewer((A_Sphericity_Ellipsoid),"Colormap",parula, "DisplayRange",[0.8 1]), colorbar, title('Sphericity Ellipsoid')

figure, sliceViewer((A_Sphericity),"Colormap",parula, "DisplayRange",[0.62 .95]), colorbar, title('Sphericity Real')

% P_A_Sphericity_Num = prctile(B_Sphericity_array_Num,[1 5 20 95 99 99.9 100],"all")
% figure, orthosliceViewer((A_Sphericity_Num),"Colormap",gray, "DisplayRange",[P_A_Sphericity_Num(1) P_A_Sphericity_Num(7)])
% title('Sphericity')


%% Output as Tiff
if WriteTiff == 1
    A_Sphericity_Scale = A_Sphericity_Ellipsoid-0.8;
    A_Sphericity_Scale = A_Sphericity_Scale/(1-0.8);

    filenametiff = FileName + "_Sphericity.tiff"
    im1 = A_Sphericity_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_Sphericity_Scale,3)
        im2 = A_Sphericity_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end
end