%% Orientation Calculation
function [A_Orientation] = OrientationCalculation(FileName, A, B,RawImage, WriteTiff)


figure, sliceViewer(RawImage)
h1 = drawline(SelectedColor="yellow");
LineCoordinates = h1.Position;
v = [LineCoordinates(1,1)-LineCoordinates(2,1) LineCoordinates(1,2)-LineCoordinates(2,2)];


for index = 1:size(B,1)
    testHull = cell2mat(B.ConvexHull(index));
    if size(testHull,1) > 9
        [ ~, ~, evecs, ~, ~ ] = ellipsoid_fit(testHull);
        u = [evecs(1,1) evecs(2,1)];
        CosTheta = max(min(dot(u,v)/(norm(u)*norm(v)),1),-1);
        ThetaInDegrees(index,1) = real(acosd(CosTheta));
    else
        ThetaInDegrees(index,1) = 0;
    end
end

for i = 1:size(ThetaInDegrees,1)
    if ThetaInDegrees(i)>90
        ThetaInDegrees(i) = abs(ThetaInDegrees(i)-180);
    end
end


tic
A_Orientation = zeros(size(A));
for i = 1:size(A,1)
    i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_Orientation(i,j,k) = ThetaInDegrees(index,1);
            end
        end
    end
end
toc


figure, sliceViewer((A_Orientation),"Colormap",parula, "DisplayRange",[0 90])
title('Cell orientation')
axis equal
colorbar

% Output as Tiff
if WriteTiff == 1
A_Orientation_Scale = A_Orientation/90;

    filenametiff = FileName + "_Orientation.tiff"
    im1 = A_Orientation_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_Orientation_Scale,3)
        im2 = A_Orientation_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end
end