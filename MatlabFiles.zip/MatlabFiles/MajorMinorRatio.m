%% Major/Minor axis ratio
function [A_PAL_R] = MajorMinorRatio(FileName, A, B, WriteTiff)

B_Axis_array = B.PrincipalAxisLength;
B_Axis_array_Ratio = B_Axis_array(:,1)./B_Axis_array(:,3);

A_PAL_R = zeros(size(A));


for i = 1:size(A,1)
    PercentFinished = i/size(A,1)*100
    for j = 1:size(A,2)
        for k = 1:size(A,3)
            index = A(i,j,k);
            if index > 0
                A_PAL_R(i,j,k) = B_Axis_array_Ratio(index,1);

            end
        end
    end
end



figure, sliceViewer((A_PAL_R),"Colormap",parula, "DisplayRange",[1 4])
title('Major/Minor axis ratio')


% Output as Tiff
if WriteTiff == 1
    A_PAL_R_Scale = A_PAL_R-1;
    A_PAL_R_Scale = A_PAL_R_Scale/(4-1);

    filenametiff = FileName + "_MajorMinorRatio.tiff"
    im1 = A_PAL_R_Scale(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_PAL_R_Scale,3)
        im2 = A_PAL_R_Scale(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end
end