%% Create Convex Hull Image
function [A_Convex] = CreateConvexHullImage(FileName, A, B, WriteTiff)
figure, sliceViewer(A)

[Solidity_Sorted,I] = sort(B.Solidity);

BoundingBox_Origin = B.BoundingBox(:,1:3);
BoundingBox_Size = B.BoundingBox(:,4:6);
BoundingBox_Origin_Scale = BoundingBox_Origin-0.5;

A_Convex = zeros(size(A));

for Index = 1:size(B,1)
    IndexScale = I(Index);
    Index/size(B,1)*100
    x = BoundingBox_Origin_Scale(IndexScale,1);
    y = BoundingBox_Origin_Scale(IndexScale,2);
    z = BoundingBox_Origin_Scale(IndexScale,3);
    TempConvex = cell2mat(B.ConvexImage(IndexScale,1));

    for i = 1:BoundingBox_Size(IndexScale, 1)
        for j = 1:BoundingBox_Size(IndexScale, 2)
            for k = 1:BoundingBox_Size(IndexScale, 3)
                if TempConvex(j,i,k) == 1
                    A_Convex(y+j, x+i, z+k) = IndexScale;
                end

            end
        end
    end

end



figure, sliceViewer(A_Convex)
if WriteTiff == 1

    % Output as Tiff
    A_Convex16 = uint16(A_Convex);
    filenametiff = FileName + "_ConvexMasks.tiff"
    im1 = A_Convex16(1:end,1:end,1);
    imwrite(im1,filenametiff)
    for i = 2:size(A_Convex16,3)
        im2 = A_Convex16(1:end,1:end,i);
        imwrite(im2,filenametiff,"WriteMode","append")
    end
end
end